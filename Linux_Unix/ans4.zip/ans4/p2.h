void p2func();
void func2();
