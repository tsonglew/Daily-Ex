#include <stdio.h>
#include "p1.h"
#include "p2.h"

int main() {
    p1func();
    p2func();
    return 0;
}
