#include <stdio.h>
#include "p2.h"
#include "p1.h"

void p2func() {
    func1();
}

void func2() {
    printf("this is func2!\n");
}
