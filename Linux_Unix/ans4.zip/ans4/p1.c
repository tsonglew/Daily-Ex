#include <stdio.h>
#include "p1.h"
#include "p2.h"

void func1() {
    printf("this is func1!\n");
}

void p1func() {
    func2();
}
