/*
 * libDebug
 *
 * Copyright (C) 2000-2004 Patrick Alken
 * This library comes with absolutely NO WARRANTY
 *
 * Should you choose to use and/or modify this source code, please
 * do so under the terms of the GNU General Public License under which
 * this library is distributed.
 *
 * $Id: version.c,v 1.3 2004/10/09 23:08:03 pa33 Exp $
 */

#ifdef VERSION
char libDebugVersion[] = VERSION;
#else
char libDebugVersion[] = "";
#endif
