/*
 * Assembly Language Debugger
 *
 * Copyright (C) 2000-2003 Patrick Alken
 * This program comes with absolutely NO WARRANTY
 *
 * Should you choose to use and/or modify this source code, please
 * do so under the terms of the GNU General Public License under which
 * this program is distributed.
 *
 * $Id: version.c,v 1.1.1.1 2004/04/26 00:39:48 pa33 Exp $
 */

#ifdef VERSION
char  galdVersion[] = VERSION;
#else
char  galdVersion[] = "";
#endif
